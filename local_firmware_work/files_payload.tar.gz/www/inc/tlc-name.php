<?php
	echo html_entity_decode(get_name());
?>
