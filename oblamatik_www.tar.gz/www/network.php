<?php
	// This script is run by a cron job every 1 minute
	// to check for the various connection modes

	// 1. If WLAN client active and no connection after 10 minutes -> switch to WLAN AP mode
	// 2. If Ethernet is active switch off WLAN completely
	// 

	include("/www/inc/functions.php");

	exec("/bin/cat /proc/net/route", $out);

	$wlan_client = 0;
	$wlan_ap = 0;
	$ethernet = 0;
	
	foreach($out as $line)
	{
		$output = preg_split('/[\s,]+/', $line);
		
		switch($output[0])
		{
			case 'wlan0':
				$wlan_client = 1;
				break;
			case 'eth1':
				$ethernet = 1;
				break;
			case 'br-lan':
				$wlan_ap = 1;
				break;
		}
	}

	echo "Ethernet:    " . $ethernet . "\n";
	echo "WLAN AP:     " . $wlan_ap , "\n";
	echo "WLAN Client: " . $wlan_client . "\n";

	$net = file_get_contents("/etc/config/wireless");
	post_log('wlan', $net);

	$uptime = file_get_contents("/proc/uptime");
	$up = explode(" " , $uptime);
	$uptime = intval($up[0] / 60);

if($uptime > 10)
{
	if($ethernet)
	{
		logtofile("Ethernet active...\n");
		// Switch of WLAN Radio
		$str = file_get_contents('/etc/config/wireless');
		$pos = strpos($str, 'option disabled 1');
		if($pos === false)
		{
			logtofile("Switching off radio...\n");
			$str = str_replace('option disabled 0', 'option disabled 1', $str);
			file_put_contents('/etc/config/wireless', $str);
			exec("/bin/chmod 666 /etc/config/wireless");
			exec('/etc/init.d/network restart', $out);
			file_put_contents('/www/config/wlan_number.txt', strval(0));
			$array['message'] = "Switch WLAN radio off";
			post_log('network', $message);
		}
	}
	else
	{
		// Ethernet is off, so activate WLAN Radio
		$str = file_get_contents('/etc/config/wireless');
		$pos = strpos($str, 'option disabled 0');
		if($pos === false)
		{
			$str = str_replace('option disabled 1', 'option disabled 0', $str);
			file_put_contents('/etc/config/wireless', $str);
			exec("/bin/chmod 666 /etc/config/wireless");
			file_put_contents('/www/config/wlan_number.txt', strval(0));
			logtofile("Switch WLAN Radio on...\n");
			exec('/etc/init.d/network restart', $out);
		}
		// WLAN is already activated
		if(preg_match('/wwan/', $str))
		{
			// And configured as WLAN Client
			if($wlan_client == 0)
			{
				// But no WLAN connection
				$number = file_get_contents('/www/config/wlan_number.txt');
				if($number)
				{
					$tries = intval($number);
				}
				else
				{
					$tries = 0;
				}
				$tries++;
				if($tries < 4)
					file_put_contents('/www/config/wlan_number.txt', strval($tries));
				else
				{
					logtofile("Maximum retries reached...\n");
					file_put_contents('/www/config/wlan_number.txt', strval(0));

					$config = file("/etc/config/wireless");
					foreach($config as $line)
					{
						if(preg_match("/ssid\s+'(.*?)'/", $line, $match))
						{
							print_r($match);
							$ssid = $match[1];
							exec("/usr/sbin/iwlist wlan0 scan | grep '" . $ssid . "'", $scan);
							if($scan)
							{
								print_r($scan);
								logtofile("We have the SSID but no connection...wrong passsword???: " . $ssid . "\n");
								exec("/usr/sbin/wpa_cli status", $output, $return);
								foreach($output as $line)
								{
									if(preg_match("/^wpa_state/", $line))
									{
										$state = explode("=", $line);
										if($state[1] == "COMPLETED")
										{
											// Save old WLAN client configuration for later reconnect retries
											$store = file_get_contents("/etc/config/wireless");
											file_put_contents("/etc/config/wireless.old", $store);
											exec("/bin/chmod 666 /etc/config/wireless*");
											exec("/bin/chown http /etc/config/wireless.old");
											exec("/bin/chgrp www-data /etc/config/wireless.old");
										}
									}
								}
							}
							else
							{
								logtofile("The WLAN SSID is absent...so store the configuration for retrying later...\n");
								// Save old WLAN client configuration for later reconnect retries
								$store = file_get_contents("/etc/config/wireless");
								file_put_contents("/etc/config/wireless.old", $store);
								exec("/bin/chmod 666 /etc/config/wireless*");
								exec("/bin/chown http /etc/config/wireless.old");
								exec("/bin/chgrp www-data /etc/config/wireless.old");
							}
						}
					}

					$str = file_get_contents('/www/config/wireless_ap');

					exec('/usr/sbin/fw_printenv passwd', $result);
					$key = explode('=', $result[0]);

					if(strlen($key[1]) > 7)
						$wlankey = $key[1];
					else
						$wlankey = "12341234";

					exec('/usr/sbin/fw_printenv serialnum', $iot);
					$serialiot = explode("=", $iot[0]);
					$serialiot = trim($serialiot[1]);
					if(!$serialiot)
						$serialiot = 'none';

					$str = str_replace("SSID", "crosswater-" . $serialiot, $str);
					$str = str_replace("KEY", $wlankey, $str);

					file_put_contents('/etc/config/wireless', $str);
					exec("/bin/chmod 666 /etc/config/wireless");
					switch_to_ap();
					exec('/etc/init.d/network restart');
				}
			}
		}
		else
		{
			file_put_contents('/www/config/wlan_number.txt', strval(0));
			// And configured as WLAN AP
			if(file_exists("/etc/config/wireless.old"))
			{
				// get the SSID of the previous configuration
				$config = file("/etc/config/wireless.old");
				foreach($config as $line)
				{
					if(preg_match("/ssid\s+'(.*?)'/", $line, $match))
					{
						print_r($match);
						$ssid = $match[1];
						exec("/usr/sbin/iwlist wlan0 scan | grep '" . $ssid . "'", $scan);
						if($scan)
						{
							print_r($scan);
							logtofile("We have found our WLAN AP again: " . $ssid . "\n");
							exec("/bin/mv /etc/config/wireless.old /etc/config/wireless");
							exec("/bin/chmod 666 /etc/config/wireless");
							switch_to_sta();
							exec("/etc/init.d/network restart");
						}
					}
				}
			}
		}
	}

}

	$localip = get_local_ip2();
	echo "Local IP: " . $localip . "\n";
	file_put_contents("/www/inc/localip.txt", $localip);

	include("/www/ws/register.php");

	if(file_exists("/www/inc/info.txt"))
	{
		$info = json_decode(file_get_contents("/www/inc/info.txt"));
		$info->ip = $localip;
//		print_r($info);
		$json = json_encode($info);
		file_put_contents("/www/inc/info.txt", $json);
	}

//	Reset user account printed on the IoT module
	include("/www/user.php");
?>
