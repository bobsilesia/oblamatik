<?php
	include("/www/inc/functions.php");
	
	exec('/usr/sbin/fw_printenv serialnum', $iot);
	$serialiot = explode("=", $iot[0]);
	$serialiot = trim($serialiot[1]);
	if(!$serialiot)
		$serialiot = 'none';

	exec('/usr/sbin/fw_printenv passwd', $passwd);
	$password = explode("=", $passwd[0]);
	$password = trim($password[1]);
	if(!$password)
		$password = 'password';

	$array = array();
//	sleep(10);
	$array['version'] = read_version();
	$array['serial_number'] = read_serial();
	for($i = 0; $i < 5; $i++)
	{
		$array['version'] = read_version();
		$array['serial_number'] = read_serial();
		if(intval($array['version']) >= 1)
		{
			file_put_contents("/tmp/tries.txt", "Tries: " . $i);
			break;
		}
		sleep(2);
	}
	$array['serial_number_iot'] = $serialiot;
	$array['password'] = hash('sha512', $password);
	$array['name'] = get_name();
	$array['ip'] = get_local_ip2();
	
	print_r($array);
	
	$info = json_encode($array);
	file_put_contents("/www/inc/info.txt", $info);
	post_log('startup', $array);

	// Build http.auth entry for IoT user
	$realm = $serialiot . ':Crosswater:' . md5($serialiot . ":Crosswater:" . $password) . "\n";
	// read in existing user file
	$users = file("/etc/lighttpd/lighttpd.user");
	$newusers = "";
	foreach($users as $user)
	{
		if(strlen($user) > 1)
		{
			// We found a user line
			$temp = explode(":", $user);
			if($tmp[0] != $serialiot)
				$newusers .= $user;
		}
	}
	$newusers .= $realm;
	file_put_contents("/etc/lighttpd/lighttpd.user", $newusers);

	exec("/bin/chown http /etc/lighttpd/lighttpd.user");
	exec("/bin/chgrp www-data /etc/lighttpd/lighttpd.user");
//	exec("/etc/init.d/sshd stop");

?>
