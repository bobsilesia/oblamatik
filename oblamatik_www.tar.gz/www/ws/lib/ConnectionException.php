<?php

namespace WebSocket;
class ConnectionException extends Exception {}
