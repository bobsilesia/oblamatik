<?php
	$info = json_decode(file_get_contents("/www/inc/info.txt"));
	if($info->serial_number_iot == 'none')
		$info->serial_number_iot = $info->serial_number;

	if(file_exists("/tmp/downloaded.txt"))
		$down = trim(file_get_contents("/tmp/downloaded.txt"));
	else
		$down = 0;

	if(file_exists("/tmp/downloaded.txt"))
		$downloaded = trim(file_get_contents("/tmp/downloaded.txt"));
	else
		$downloaded = "0";

	if(file_exists("/etc/socket.conf"))
		$server = trim(file_get_contents("/etc/socket.conf"));
	else
	{
		$server = 'stage-oblamatik.impac.ch';
	}

	$array['password'] = $info->password;
	$array['serial_number'] = $info->serial_number;
	$array['serial_number_iot'] = $info->serial_number_iot;
	$array['type'] = '1';
	$array['hash'] = hash('sha512', $info->password . 'hugogehtgernefischen');
	$array['mac_address'] = trim(read_mac_wlan());
	$array['ip_address'] = $info->ip;
	$array['version_number'] = get_url('https://127.0.0.1/api/version/');
	if(file_exists("/tmp/downloaded.txt"))
	{
		$downloaded = trim(file_get_contents("/tmp/downloaded.txt"));
	}
	else
		$downloaded = 0;
	$array['version_number_downloaded'] = $downloaded;
	$array['name'] = get_url('https://127.0.0.1/api/tlc/1/name/');

	$settings['ip'] = trim(file_get_contents("http://myexternalip.com/raw"));
	$settings['uptime'] = $uptime;
	$settings['kernel'] = trim(php_uname(r));
	$array['settings'] = json_encode($settings);

	print_r($array);

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL,"https://" . $server . "/api/add-iot/");
	curl_setopt($ch, CURLOPT_PORT, 443);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array));
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
	curl_setopt($ch, CURLOPT_CAINFO, "/etc/certs/ca-bundle.crt");

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$server_output = json_decode(curl_exec ($ch));

	curl_close ($ch);

	print_r($server_output);

	echo "Channel: " . $server_output->channel . "\n";

	switch($server_output->status)
	{
		case 200:
		case 418:
			file_put_contents("/tmp/channel.txt", $server_output->channel);
			break;
		default:
			file_put_contents("/tmp/channel.txt", "0");
			break;
	}

?>
